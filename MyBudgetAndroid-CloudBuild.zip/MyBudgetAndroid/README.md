# My Budget (Android)

Aplikasi budgeting offline berbasis Kotlin, Jetpack Compose, dan Room.

## Fitur pada versi awal
- Dashboard dengan pendapatan bulanan default Rp4.500.000.
- Ringkasan pengeluaran, investasi, dan sisa uang.
- Daftar alokasi anggaran bulanan.
- Tambah/hapus transaksi pengeluaran.
- Catat pembelian saham: ticker, nama perusahaan, lot, harga per lembar, biaya transaksi, dividen, tanggal, dan catatan.
- Data tersimpan lokal di database Room pada perangkat.

## Cara membuka dan menjalankan
1. Instal Android Studio versi terbaru.
2. Ekstrak folder `MyBudgetAndroid`.
3. Android Studio > Open > pilih folder `MyBudgetAndroid`.
4. Tunggu Gradle Sync selesai. Gunakan JDK 17.
5. Hubungkan HP Android dengan USB debugging aktif, atau jalankan emulator.
6. Tekan tombol Run.

## Membuat APK
Di Android Studio pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
APK debug biasanya tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan versi awal
- Pendapatan masih default Rp4.500.000 di `MainActivity.kt`.
- Alokasi anggaran ditampilkan sebagai rencana tetap, belum bisa diedit dari UI.
- Riwayat transaksi tersimpan offline. Menghapus aplikasi dapat menghapus database lokal; lakukan backup perangkat sebelum uninstall.
- Versi ini belum mengambil harga saham real-time dan belum menghitung average cost gabungan antar transaksi. Catatan pembelian disimpan per transaksi.

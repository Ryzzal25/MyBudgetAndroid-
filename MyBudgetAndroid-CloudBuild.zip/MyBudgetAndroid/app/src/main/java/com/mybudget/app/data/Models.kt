package com.mybudget.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String,
    val amount: Long,
    val dateMillis: Long = System.currentTimeMillis(),
    val note: String = ""
)

@Entity(tableName = "investments")
data class Investment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val ticker: String,
    val company: String,
    val lots: Int,
    val pricePerShare: Long,
    val fee: Long = 0,
    val dividend: Long = 0,
    val dateMillis: Long = System.currentTimeMillis(),
    val note: String = ""
) {
    val shares: Long get() = lots.toLong() * 100L
    val grossValue: Long get() = shares * pricePerShare
    val totalCost: Long get() = grossValue + fee
}

package com.mybudget.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.room.Room
import com.mybudget.app.data.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Green = Color(0xFF087F68)
private val Bg = Color(0xFFF5F7F6)
private val moneyFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply {
    maximumFractionDigits = 0
    minimumFractionDigits = 0
}
private fun rupiah(value: Long) = moneyFormat.format(value).replace("Rp", "Rp ")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = BudgetDatabase.get(this).dao()
        setContent { MyBudgetApp(dao) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyBudgetApp(dao: BudgetDao) {
    val scope = rememberCoroutineScope()
    val expenses by dao.observeExpenses().collectAsState(initial = emptyList())
    val investments by dao.observeInvestments().collectAsState(initial = emptyList())
    var tab by remember { mutableIntStateOf(0) }
    var showExpense by remember { mutableStateOf(false) }
    var showInvestment by remember { mutableStateOf(false) }

    val now = remember { System.currentTimeMillis() }
    val calendar = remember(now) { java.util.Calendar.getInstance().apply { timeInMillis = now } }
    val month = calendar.get(java.util.Calendar.MONTH)
    val year = calendar.get(java.util.Calendar.YEAR)
    fun inThisMonth(millis: Long): Boolean {
        val c = java.util.Calendar.getInstance().apply { timeInMillis = millis }
        return c.get(java.util.Calendar.MONTH) == month &&
            c.get(java.util.Calendar.YEAR) == year
    }
    val monthExpenses = expenses.filter { inThisMonth(it.dateMillis) }
    val monthInvestments = investments.filter { inThisMonth(it.dateMillis) }
    val spent = monthExpenses.sumOf { it.amount }
    val invested = monthInvestments.sumOf { it.totalCost }
    val income = 4_500_000L
    val remaining = income - spent - invested

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green,
            secondary = Color(0xFF4F7C72),
            background = Bg,
            surface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Bg,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("My Budget", fontWeight = FontWeight.Bold)
                            Text("Keuangan bulananmu", fontSize = 12.sp, color = Color.Gray)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg)
                )
            },
            floatingActionButton = {
                FloatingActionButton(
                    onClick = { if (tab == 0) showExpense = true else showInvestment = true },
                    containerColor = Green,
                    contentColor = Color.White
                ) { Icon(Icons.Default.Add, contentDescription = "Tambah") }
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(
                        selected = tab == 0,
                        onClick = { tab = 0 },
                        icon = { Icon(Icons.Default.AccountBalanceWallet, null) },
                        label = { Text("Budget") }
                    )
                    NavigationBarItem(
                        selected = tab == 1,
                        onClick = { tab = 1 },
                        icon = { Icon(Icons.Default.ShowChart, null) },
                        label = { Text("Investasi") }
                    )
                }
            }
        ) { padding ->
            if (tab == 0) {
                BudgetScreen(
                    modifier = Modifier.padding(padding),
                    income = income,
                    spent = spent,
                    invested = invested,
                    remaining = remaining,
                    expenses = monthExpenses,
                    onDelete = { id -> scope.launch { dao.deleteExpense(id) } }
                )
            } else {
                InvestmentScreen(
                    modifier = Modifier.padding(padding),
                    investments = investments,
                    monthInvested = invested,
                    onDelete = { id -> scope.launch { dao.deleteInvestment(id) } }
                )
            }
        }
    }

    if (showExpense) {
        ExpenseDialog(
            onDismiss = { showExpense = false },
            onSave = { title, category, amount, note ->
                scope.launch {
                    dao.insertExpense(Expense(title = title, category = category, amount = amount, note = note))
                }
                showExpense = false
            }
        )
    }
    if (showInvestment) {
        InvestmentDialog(
            onDismiss = { showInvestment = false },
            onSave = { ticker, company, lots, price, fee, dividend, note ->
                scope.launch {
                    dao.insertInvestment(
                        Investment(
                            ticker = ticker.uppercase(), company = company, lots = lots,
                            pricePerShare = price, fee = fee, dividend = dividend, note = note
                        )
                    )
                }
                showInvestment = false
            }
        )
    }
}

@Composable
private fun BudgetScreen(
    modifier: Modifier,
    income: Long,
    spent: Long,
    invested: Long,
    remaining: Long,
    expenses: List<Expense>,
    onDelete: (Long) -> Unit
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Green)) {
                Column(Modifier.padding(20.dp)) {
                    Text("Sisa uang bulan ini", color = Color.White.copy(alpha = .8f))
                    Text(rupiah(remaining), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(16.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        SummaryMini("Pendapatan", rupiah(income))
                        SummaryMini("Pengeluaran", rupiah(spent))
                        SummaryMini("Investasi", rupiah(invested))
                    }
                }
            }
        }
        item {
            SectionTitle("Ringkasan anggaran")
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    BudgetLine("Kost", 600_000, income)
                    BudgetLine("Orang tua", 500_000, income)
                    BudgetLine("Transportasi", 400_000, income)
                    BudgetLine("Makan", 900_000, income)
                    BudgetLine("Pulsa & internet", 100_000, income)
                    BudgetLine("Kebutuhan pribadi", 200_000, income)
                    BudgetLine("Kesehatan", 100_000, income)
                    BudgetLine("Hiburan", 150_000, income)
                    BudgetLine("Dana darurat", 550_000, income)
                    BudgetLine("Investasi DCA", 900_000, income)
                    BudgetLine("Dana cadangan", 100_000, income)
                }
            }
        }
        item { SectionTitle("Transaksi pengeluaran") }
        if (expenses.isEmpty()) {
            item { EmptyState("Belum ada pengeluaran bulan ini", "Tekan tombol + untuk mencatat transaksi.") }
        } else {
            items(expenses, key = { it.id }) { expense ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Row(
                        Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(expense.title, fontWeight = FontWeight.SemiBold)
                            Text("${expense.category} • ${dateText(expense.dateMillis)}", color = Color.Gray, fontSize = 12.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(rupiah(expense.amount), fontWeight = FontWeight.Bold)
                            TextButton(onClick = { onDelete(expense.id) }) { Text("Hapus") }
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(70.dp)) }
    }
}

@Composable
private fun InvestmentScreen(
    modifier: Modifier,
    investments: List<Investment>,
    monthInvested: Long,
    onDelete: (Long) -> Unit
) {
    val totalCost = investments.sumOf { it.totalCost }
    val totalDividend = investments.sumOf { it.dividend }
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF173D52))) {
                Column(Modifier.padding(20.dp)) {
                    Text("Investasi bulan ini", color = Color.White.copy(alpha = .8f))
                    Text(rupiah(monthInvested), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        SummaryMini("Total modal", rupiah(totalCost))
                        SummaryMini("Dividen dicatat", rupiah(totalDividend))
                    }
                }
            }
        }
        item { SectionTitle("Riwayat pembelian saham") }
        if (investments.isEmpty()) {
            item { EmptyState("Belum ada data investasi", "Tekan + untuk mencatat pembelian saham.") }
        } else {
            items(investments, key = { it.id }) { inv ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${inv.ticker} • ${inv.company}", fontWeight = FontWeight.Bold)
                            Text(rupiah(inv.totalCost), fontWeight = FontWeight.Bold, color = Green)
                        }
                        Text("${inv.lots} lot (${inv.shares} lembar) × ${rupiah(inv.pricePerShare)}", fontSize = 13.sp)
                        Text("Biaya: ${rupiah(inv.fee)}  •  Dividen: ${rupiah(inv.dividend)}", color = Color.Gray, fontSize = 12.sp)
                        Text(dateText(inv.dateMillis), color = Color.Gray, fontSize = 12.sp)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            TextButton(onClick = { onDelete(inv.id) }) { Text("Hapus") }
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(70.dp)) }
    }
}

@Composable
private fun SummaryMini(label: String, value: String) {
    Column {
        Text(label, color = Color.White.copy(alpha = .75f), fontSize = 11.sp)
        Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
}

@Composable
private fun BudgetLine(name: String, amount: Long, total: Long) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(name, fontSize = 13.sp)
            Text(rupiah(amount), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
        LinearProgressIndicator(
            progress = { (amount.toFloat() / total).coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(5.dp),
            color = Green,
            trackColor = Color(0xFFE8EFEC)
        )
    }
}

@Composable
private fun EmptyState(title: String, subtitle: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Color.Gray, fontSize = 12.sp)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ExpenseDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, Long, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Makan") }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    val categories = listOf("Kost", "Orang tua", "Transportasi", "Makan", "Pulsa & internet", "Kebutuhan pribadi", "Kesehatan", "Hiburan", "Lainnya")
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tambah pengeluaran") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Nama transaksi") }, singleLine = true)
                var expanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                    OutlinedTextField(category, {}, readOnly = true, label = { Text("Kategori") }, modifier = Modifier.menuAnchor())
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        categories.forEach { option ->
                            DropdownMenuItem(text = { Text(option) }, onClick = { category = option; expanded = false })
                        }
                    }
                }
                OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("Nominal (Rp)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(note, { note = it }, label = { Text("Catatan (opsional)") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(
                enabled = title.isNotBlank() && (amount.toLongOrNull() ?: 0) > 0,
                onClick = { onSave(title.trim(), category, amount.toLong(), note.trim()) }
            ) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

@Composable
private fun InvestmentDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, Int, Long, Long, Long, String) -> Unit
) {
    var ticker by remember { mutableStateOf("") }
    var company by remember { mutableStateOf("") }
    var lots by remember { mutableStateOf("1") }
    var price by remember { mutableStateOf("") }
    var fee by remember { mutableStateOf("0") }
    var dividend by remember { mutableStateOf("0") }
    var note by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Catat pembelian saham") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(ticker, { ticker = it.uppercase() }, label = { Text("Kode saham (contoh: BBCA)") }, singleLine = true)
                OutlinedTextField(company, { company = it }, label = { Text("Nama perusahaan") }, singleLine = true)
                OutlinedTextField(lots, { lots = it.filter(Char::isDigit) }, label = { Text("Jumlah lot (1 lot = 100 lembar)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(price, { price = it.filter(Char::isDigit) }, label = { Text("Harga per lembar (Rp)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(fee, { fee = it.filter(Char::isDigit) }, label = { Text("Biaya transaksi (Rp)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(dividend, { dividend = it.filter(Char::isDigit) }, label = { Text("Dividen diterima (Rp)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(note, { note = it }, label = { Text("Catatan (opsional)") }, singleLine = true)
                val estimated = (lots.toLongOrNull() ?: 0L) * 100L * (price.toLongOrNull() ?: 0L) + (fee.toLongOrNull() ?: 0L)
                Text("Estimasi total pembelian: ${rupiah(estimated)}", fontWeight = FontWeight.SemiBold, color = Green, fontSize = 13.sp)
            }
        },
        confirmButton = {
            TextButton(
                enabled = ticker.isNotBlank() && company.isNotBlank() &&
                    (lots.toIntOrNull() ?: 0) > 0 && (price.toLongOrNull() ?: 0) > 0,
                onClick = {
                    onSave(ticker.trim(), company.trim(), lots.toInt(), price.toLong(),
                        fee.toLongOrNull() ?: 0, dividend.toLongOrNull() ?: 0, note.trim())
                }
            ) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

private fun dateText(millis: Long): String =
    SimpleDateFormat("dd MMM yyyy", Locale("id", "ID")).format(Date(millis))
